﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace GUI.ThuNgan
{
    public partial class frmThemMonAn : DevExpress.XtraEditors.XtraForm
    {
        public frmThemMonAn()
        {
            InitializeComponent();
        }
    }
}