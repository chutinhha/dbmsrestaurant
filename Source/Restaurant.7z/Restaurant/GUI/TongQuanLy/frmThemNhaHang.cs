﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace GUI.TongQuanLy
{
    public partial class frmThemNhaHang : DevExpress.XtraEditors.XtraForm
    {
        public frmThemNhaHang()
        {
            InitializeComponent();
        }
    }
}