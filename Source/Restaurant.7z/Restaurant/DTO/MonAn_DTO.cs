﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace DTO
{
    public class MonAn_DTO
    {
        string maMonAn;

        public string MaMonAn
        {
            get { return maMonAn; }
            set { maMonAn = value; }
        }
        string tenMonAn;

        public string TenMonAn
        {
            get { return tenMonAn; }
            set { tenMonAn = value; }
        }

        string maLoai;

        public string MaLoai
        {
            get { return maLoai; }
            set { maLoai = value; }
        }

        string gia;

        public string Gia
        {
            get { return gia; }
            set { gia = value; }
        }

        string donViTinh;

        public string DonViTinh
        {
            get { return donViTinh; }
            set { donViTinh = value; }
        }

        string maNhaHang;

        public string MaNhaHang
        {
            get { return maNhaHang; }
            set { maNhaHang = value; }
        }

    }
}
