﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace GUI.QuanLyKho
{
    public partial class frmLapPhieuNhapKho : DevExpress.XtraEditors.XtraForm
    {
        public frmLapPhieuNhapKho()
        {
            InitializeComponent();
        }
    }
}