﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using DevExpress.XtraEditors;

namespace GUI.QuanLyNhaHang
{
    public partial class UCtrlQLDanhSachBanAn : DevExpress.XtraEditors.XtraUserControl
    {
        public UCtrlQLDanhSachBanAn()
        {
            InitializeComponent();
        }
    }
}
