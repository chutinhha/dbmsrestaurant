﻿namespace GUI.ThuNgan
{
    partial class UCtrlQLTBanAn
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(UCtrlQLTBanAn));
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.listBoxBanAn = new System.Windows.Forms.ListBox();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl2 = new DevExpress.XtraEditors.LabelControl();
            this.comboBoxEdit1 = new DevExpress.XtraEditors.ComboBoxEdit();
            this.comboBoxEdit2 = new DevExpress.XtraEditors.ComboBoxEdit();
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.gridDSMon = new DevExpress.XtraGrid.GridControl();
            this.GridView_DSMon = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.textEditTT1 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl3 = new DevExpress.XtraEditors.LabelControl();
            this.textEditVAT = new DevExpress.XtraEditors.TextEdit();
            this.labelControl4 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl5 = new DevExpress.XtraEditors.LabelControl();
            this.textEditTT2 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl6 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl7 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl8 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl9 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl10 = new DevExpress.XtraEditors.LabelControl();
            this.textEditGiamGia = new DevExpress.XtraEditors.TextEdit();
            this.textEditTT3 = new DevExpress.XtraEditors.TextEdit();
            this.labelControl11 = new DevExpress.XtraEditors.LabelControl();
            this.TextEditTongTien = new DevExpress.XtraEditors.TextEdit();
            this.labelControl12 = new DevExpress.XtraEditors.LabelControl();
            this.labelControl13 = new DevExpress.XtraEditors.LabelControl();
            this.simpleButton2 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton3 = new DevExpress.XtraEditors.SimpleButton();
            this.splitContainer1 = new System.Windows.Forms.SplitContainer();
            this.simpleButton1 = new DevExpress.XtraEditors.SimpleButton();
            this.simpleButton5 = new DevExpress.XtraEditors.SimpleButton();
            this.btnTru = new DevExpress.XtraEditors.SimpleButton();
            this.btnCong = new DevExpress.XtraEditors.SimpleButton();
            this.printingSystem2 = new DevExpress.XtraPrinting.PrintingSystem(this.components);
            this.printableComponentLink2 = new DevExpress.XtraPrinting.PrintableComponentLink(this.components);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.comboBoxEdit1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboBoxEdit2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridDSMon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView_DSMon)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditTT1.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditVAT.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditTT2.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditGiamGia.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditTT3.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextEditTongTien.Properties)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).BeginInit();
            this.splitContainer1.Panel1.SuspendLayout();
            this.splitContainer1.Panel2.SuspendLayout();
            this.splitContainer1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.printingSystem2)).BeginInit();
            this.SuspendLayout();
            // 
            // groupControl1
            // 
            this.groupControl1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)));
            this.groupControl1.Controls.Add(this.listBoxBanAn);
            this.groupControl1.Location = new System.Drawing.Point(3, 72);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(230, 405);
            this.groupControl1.TabIndex = 0;
            this.groupControl1.Text = "Danh Sách Bàn Đang Sử Dụng";
            // 
            // listBoxBanAn
            // 
            this.listBoxBanAn.Dock = System.Windows.Forms.DockStyle.Fill;
            this.listBoxBanAn.Font = new System.Drawing.Font("Tahoma", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.listBoxBanAn.FormattingEnabled = true;
            this.listBoxBanAn.ItemHeight = 18;
            this.listBoxBanAn.Location = new System.Drawing.Point(2, 22);
            this.listBoxBanAn.Name = "listBoxBanAn";
            this.listBoxBanAn.Size = new System.Drawing.Size(226, 381);
            this.listBoxBanAn.TabIndex = 0;
            this.listBoxBanAn.SelectedIndexChanged += new System.EventHandler(this.listBoxBanAn_SelectedIndexChanged);
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(5, 16);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(40, 13);
            this.labelControl1.TabIndex = 1;
            this.labelControl1.Text = "Loại Bàn";
            // 
            // labelControl2
            // 
            this.labelControl2.Location = new System.Drawing.Point(5, 46);
            this.labelControl2.Name = "labelControl2";
            this.labelControl2.Size = new System.Drawing.Size(39, 13);
            this.labelControl2.TabIndex = 1;
            this.labelControl2.Text = "Khu Vực";
            // 
            // comboBoxEdit1
            // 
            this.comboBoxEdit1.Location = new System.Drawing.Point(51, 43);
            this.comboBoxEdit1.Name = "comboBoxEdit1";
            this.comboBoxEdit1.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.comboBoxEdit1.Size = new System.Drawing.Size(180, 20);
            this.comboBoxEdit1.TabIndex = 2;
            // 
            // comboBoxEdit2
            // 
            this.comboBoxEdit2.Location = new System.Drawing.Point(51, 13);
            this.comboBoxEdit2.Name = "comboBoxEdit2";
            this.comboBoxEdit2.Properties.Buttons.AddRange(new DevExpress.XtraEditors.Controls.EditorButton[] {
            new DevExpress.XtraEditors.Controls.EditorButton(DevExpress.XtraEditors.Controls.ButtonPredefines.Combo)});
            this.comboBoxEdit2.Size = new System.Drawing.Size(180, 20);
            this.comboBoxEdit2.TabIndex = 2;
            // 
            // groupControl2
            // 
            this.groupControl2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupControl2.Controls.Add(this.gridDSMon);
            this.groupControl2.Location = new System.Drawing.Point(241, 46);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(636, 271);
            this.groupControl2.TabIndex = 3;
            this.groupControl2.Text = "Danh Sách Món Ăn";
            // 
            // gridDSMon
            // 
            this.gridDSMon.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridDSMon.Location = new System.Drawing.Point(2, 22);
            this.gridDSMon.MainView = this.GridView_DSMon;
            this.gridDSMon.Name = "gridDSMon";
            this.gridDSMon.Size = new System.Drawing.Size(632, 247);
            this.gridDSMon.TabIndex = 0;
            this.gridDSMon.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.GridView_DSMon});
            // 
            // GridView_DSMon
            // 
            this.GridView_DSMon.GridControl = this.gridDSMon;
            this.GridView_DSMon.Name = "GridView_DSMon";
            this.GridView_DSMon.OptionsBehavior.Editable = false;
            this.GridView_DSMon.OptionsView.ShowGroupPanel = false;
            this.GridView_DSMon.FocusedRowChanged += new DevExpress.XtraGrid.Views.Base.FocusedRowChangedEventHandler(this.GridView_DSMon_FocusedRowChanged);
            // 
            // textEditTT1
            // 
            this.textEditTT1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textEditTT1.Location = new System.Drawing.Point(243, 323);
            this.textEditTT1.Name = "textEditTT1";
            this.textEditTT1.Properties.Appearance.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(192)))));
            this.textEditTT1.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 12F);
            this.textEditTT1.Properties.Appearance.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(0)))), ((int)(((byte)(0)))));
            this.textEditTT1.Properties.Appearance.Options.UseBackColor = true;
            this.textEditTT1.Properties.Appearance.Options.UseFont = true;
            this.textEditTT1.Properties.Appearance.Options.UseForeColor = true;
            this.textEditTT1.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textEditTT1.Size = new System.Drawing.Size(605, 26);
            this.textEditTT1.TabIndex = 4;
            // 
            // labelControl3
            // 
            this.labelControl3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelControl3.Location = new System.Drawing.Point(4, 10);
            this.labelControl3.Name = "labelControl3";
            this.labelControl3.Size = new System.Drawing.Size(19, 13);
            this.labelControl3.TabIndex = 5;
            this.labelControl3.Text = "VAT";
            // 
            // textEditVAT
            // 
            this.textEditVAT.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textEditVAT.EditValue = "10";
            this.textEditVAT.Location = new System.Drawing.Point(29, 7);
            this.textEditVAT.Name = "textEditVAT";
            this.textEditVAT.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textEditVAT.Size = new System.Drawing.Size(39, 20);
            this.textEditVAT.TabIndex = 6;
            // 
            // labelControl4
            // 
            this.labelControl4.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelControl4.Location = new System.Drawing.Point(71, 10);
            this.labelControl4.Name = "labelControl4";
            this.labelControl4.Size = new System.Drawing.Size(11, 13);
            this.labelControl4.TabIndex = 5;
            this.labelControl4.Text = "%";
            // 
            // labelControl5
            // 
            this.labelControl5.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelControl5.Location = new System.Drawing.Point(96, 10);
            this.labelControl5.Name = "labelControl5";
            this.labelControl5.Size = new System.Drawing.Size(53, 13);
            this.labelControl5.TabIndex = 5;
            this.labelControl5.Text = "Thành Tiền";
            // 
            // textEditTT2
            // 
            this.textEditTT2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textEditTT2.Location = new System.Drawing.Point(155, 7);
            this.textEditTT2.Name = "textEditTT2";
            this.textEditTT2.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textEditTT2.Size = new System.Drawing.Size(108, 20);
            this.textEditTT2.TabIndex = 6;
            // 
            // labelControl6
            // 
            this.labelControl6.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.labelControl6.Location = new System.Drawing.Point(269, 9);
            this.labelControl6.Name = "labelControl6";
            this.labelControl6.Size = new System.Drawing.Size(21, 13);
            this.labelControl6.TabIndex = 5;
            this.labelControl6.Text = "VNĐ";
            // 
            // labelControl7
            // 
            this.labelControl7.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelControl7.Location = new System.Drawing.Point(1, 10);
            this.labelControl7.Name = "labelControl7";
            this.labelControl7.Size = new System.Drawing.Size(41, 13);
            this.labelControl7.TabIndex = 5;
            this.labelControl7.Text = "Giảm Giá";
            // 
            // labelControl8
            // 
            this.labelControl8.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelControl8.Location = new System.Drawing.Point(122, 10);
            this.labelControl8.Name = "labelControl8";
            this.labelControl8.Size = new System.Drawing.Size(53, 13);
            this.labelControl8.TabIndex = 5;
            this.labelControl8.Text = "Thành Tiền";
            // 
            // labelControl9
            // 
            this.labelControl9.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.labelControl9.Location = new System.Drawing.Point(291, 9);
            this.labelControl9.Name = "labelControl9";
            this.labelControl9.Size = new System.Drawing.Size(21, 13);
            this.labelControl9.TabIndex = 5;
            this.labelControl9.Text = "VNĐ";
            // 
            // labelControl10
            // 
            this.labelControl10.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelControl10.Location = new System.Drawing.Point(96, 10);
            this.labelControl10.Name = "labelControl10";
            this.labelControl10.Size = new System.Drawing.Size(11, 13);
            this.labelControl10.TabIndex = 5;
            this.labelControl10.Text = "%";
            // 
            // textEditGiamGia
            // 
            this.textEditGiamGia.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.textEditGiamGia.EditValue = "0";
            this.textEditGiamGia.Location = new System.Drawing.Point(54, 7);
            this.textEditGiamGia.Name = "textEditGiamGia";
            this.textEditGiamGia.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textEditGiamGia.Size = new System.Drawing.Size(39, 20);
            this.textEditGiamGia.TabIndex = 6;
            this.textEditGiamGia.EditValueChanged += new System.EventHandler(this.textEditGiamGia_EditValueChanged);
            // 
            // textEditTT3
            // 
            this.textEditTT3.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.textEditTT3.Location = new System.Drawing.Point(181, 7);
            this.textEditTT3.Name = "textEditTT3";
            this.textEditTT3.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.textEditTT3.Size = new System.Drawing.Size(104, 20);
            this.textEditTT3.TabIndex = 6;
            // 
            // labelControl11
            // 
            this.labelControl11.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)));
            this.labelControl11.Location = new System.Drawing.Point(333, 414);
            this.labelControl11.Name = "labelControl11";
            this.labelControl11.Size = new System.Drawing.Size(47, 13);
            this.labelControl11.TabIndex = 7;
            this.labelControl11.Text = "Tổng Tiền";
            // 
            // TextEditTongTien
            // 
            this.TextEditTongTien.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.TextEditTongTien.Location = new System.Drawing.Point(392, 399);
            this.TextEditTongTien.Name = "TextEditTongTien";
            this.TextEditTongTien.Properties.Appearance.BackColor = System.Drawing.SystemColors.HotTrack;
            this.TextEditTongTien.Properties.Appearance.Font = new System.Drawing.Font("Tahoma", 17F, System.Drawing.FontStyle.Bold);
            this.TextEditTongTien.Properties.Appearance.ForeColor = System.Drawing.Color.White;
            this.TextEditTongTien.Properties.Appearance.Options.UseBackColor = true;
            this.TextEditTongTien.Properties.Appearance.Options.UseFont = true;
            this.TextEditTongTien.Properties.Appearance.Options.UseForeColor = true;
            this.TextEditTongTien.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
            this.TextEditTongTien.Size = new System.Drawing.Size(456, 34);
            this.TextEditTongTien.TabIndex = 8;
            // 
            // labelControl12
            // 
            this.labelControl12.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.labelControl12.Location = new System.Drawing.Point(854, 331);
            this.labelControl12.Name = "labelControl12";
            this.labelControl12.Size = new System.Drawing.Size(21, 13);
            this.labelControl12.TabIndex = 5;
            this.labelControl12.Text = "VNĐ";
            // 
            // labelControl13
            // 
            this.labelControl13.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.labelControl13.Location = new System.Drawing.Point(854, 414);
            this.labelControl13.Name = "labelControl13";
            this.labelControl13.Size = new System.Drawing.Size(21, 13);
            this.labelControl13.TabIndex = 5;
            this.labelControl13.Text = "VNĐ";
            // 
            // simpleButton2
            // 
            this.simpleButton2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.simpleButton2.Location = new System.Drawing.Point(718, 445);
            this.simpleButton2.Name = "simpleButton2";
            this.simpleButton2.Size = new System.Drawing.Size(157, 30);
            this.simpleButton2.TabIndex = 9;
            this.simpleButton2.Text = "Lập Hóa Đơn Tính Tiền";
            this.simpleButton2.Click += new System.EventHandler(this.simpleButton2_Click);
            // 
            // simpleButton3
            // 
            this.simpleButton3.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.simpleButton3.Location = new System.Drawing.Point(584, 445);
            this.simpleButton3.Name = "simpleButton3";
            this.simpleButton3.Size = new System.Drawing.Size(128, 30);
            this.simpleButton3.TabIndex = 9;
            this.simpleButton3.Text = "Kết Thúc";
            this.simpleButton3.Click += new System.EventHandler(this.simpleButton3_Click);
            // 
            // splitContainer1
            // 
            this.splitContainer1.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.splitContainer1.IsSplitterFixed = true;
            this.splitContainer1.Location = new System.Drawing.Point(243, 357);
            this.splitContainer1.Name = "splitContainer1";
            // 
            // splitContainer1.Panel1
            // 
            this.splitContainer1.Panel1.Controls.Add(this.textEditVAT);
            this.splitContainer1.Panel1.Controls.Add(this.labelControl3);
            this.splitContainer1.Panel1.Controls.Add(this.labelControl5);
            this.splitContainer1.Panel1.Controls.Add(this.labelControl6);
            this.splitContainer1.Panel1.Controls.Add(this.labelControl4);
            this.splitContainer1.Panel1.Controls.Add(this.textEditTT2);
            // 
            // splitContainer1.Panel2
            // 
            this.splitContainer1.Panel2.Controls.Add(this.textEditTT3);
            this.splitContainer1.Panel2.Controls.Add(this.labelControl7);
            this.splitContainer1.Panel2.Controls.Add(this.labelControl8);
            this.splitContainer1.Panel2.Controls.Add(this.labelControl9);
            this.splitContainer1.Panel2.Controls.Add(this.labelControl10);
            this.splitContainer1.Panel2.Controls.Add(this.textEditGiamGia);
            this.splitContainer1.Size = new System.Drawing.Size(632, 34);
            this.splitContainer1.SplitterDistance = 316;
            this.splitContainer1.TabIndex = 10;
            // 
            // simpleButton1
            // 
            this.simpleButton1.Location = new System.Drawing.Point(241, 14);
            this.simpleButton1.Name = "simpleButton1";
            this.simpleButton1.Size = new System.Drawing.Size(145, 23);
            this.simpleButton1.TabIndex = 13;
            this.simpleButton1.Text = "Thêm Món Ăn";
            this.simpleButton1.Click += new System.EventHandler(this.simpleButton1_Click);
            // 
            // simpleButton5
            // 
            this.simpleButton5.Location = new System.Drawing.Point(392, 14);
            this.simpleButton5.Name = "simpleButton5";
            this.simpleButton5.Size = new System.Drawing.Size(91, 23);
            this.simpleButton5.TabIndex = 14;
            this.simpleButton5.Text = "Xóa Món Ăn";
            this.simpleButton5.Click += new System.EventHandler(this.simpleButton5_Click);
            // 
            // btnTru
            // 
            this.btnTru.Appearance.Font = new System.Drawing.Font("Simplified Arabic", 20F);
            this.btnTru.Appearance.Options.UseFont = true;
            this.btnTru.Location = new System.Drawing.Point(564, 14);
            this.btnTru.Name = "btnTru";
            this.btnTru.Size = new System.Drawing.Size(58, 23);
            this.btnTru.TabIndex = 31;
            this.btnTru.Text = "-";
            this.btnTru.Click += new System.EventHandler(this.btnTru_Click);
            // 
            // btnCong
            // 
            this.btnCong.Appearance.Font = new System.Drawing.Font("Simplified Arabic", 20F);
            this.btnCong.Appearance.Options.UseFont = true;
            this.btnCong.Location = new System.Drawing.Point(500, 14);
            this.btnCong.Name = "btnCong";
            this.btnCong.Size = new System.Drawing.Size(58, 23);
            this.btnCong.TabIndex = 32;
            this.btnCong.Text = "+";
            this.btnCong.Click += new System.EventHandler(this.btnCong_Click);
            // 
            // printingSystem2
            // 
            this.printingSystem2.Links.AddRange(new object[] {
            this.printableComponentLink2});
            // 
            // printableComponentLink2
            // 
            this.printableComponentLink2.Component = this.gridDSMon;
            // 
            // 
            // 
            this.printableComponentLink2.ImageCollection.ImageStream = ((DevExpress.Utils.ImageCollectionStreamer)(resources.GetObject("printableComponentLink2.ImageCollection.ImageStream")));
            this.printableComponentLink2.PaperKind = System.Drawing.Printing.PaperKind.A4;
            this.printableComponentLink2.PrintingSystem = this.printingSystem2;
            this.printableComponentLink2.PrintingSystemBase = this.printingSystem2;
            // 
            // UCtrlQLTBanAn
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnTru);
            this.Controls.Add(this.btnCong);
            this.Controls.Add(this.simpleButton5);
            this.Controls.Add(this.simpleButton1);
            this.Controls.Add(this.splitContainer1);
            this.Controls.Add(this.simpleButton3);
            this.Controls.Add(this.simpleButton2);
            this.Controls.Add(this.TextEditTongTien);
            this.Controls.Add(this.labelControl11);
            this.Controls.Add(this.labelControl13);
            this.Controls.Add(this.labelControl12);
            this.Controls.Add(this.textEditTT1);
            this.Controls.Add(this.groupControl2);
            this.Controls.Add(this.comboBoxEdit2);
            this.Controls.Add(this.comboBoxEdit1);
            this.Controls.Add(this.labelControl2);
            this.Controls.Add(this.labelControl1);
            this.Controls.Add(this.groupControl1);
            this.Name = "UCtrlQLTBanAn";
            this.Size = new System.Drawing.Size(880, 480);
            this.Load += new System.EventHandler(this.UCtrlQLTBanAn_Load);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.comboBoxEdit1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.comboBoxEdit2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridDSMon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GridView_DSMon)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditTT1.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditVAT.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditTT2.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditGiamGia.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.textEditTT3.Properties)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.TextEditTongTien.Properties)).EndInit();
            this.splitContainer1.Panel1.ResumeLayout(false);
            this.splitContainer1.Panel1.PerformLayout();
            this.splitContainer1.Panel2.ResumeLayout(false);
            this.splitContainer1.Panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.splitContainer1)).EndInit();
            this.splitContainer1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.printingSystem2)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private DevExpress.XtraEditors.GroupControl groupControl1;
        private System.Windows.Forms.ListBox listBoxBanAn;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl labelControl2;
        private DevExpress.XtraEditors.ComboBoxEdit comboBoxEdit1;
        private DevExpress.XtraEditors.ComboBoxEdit comboBoxEdit2;
        private DevExpress.XtraEditors.GroupControl groupControl2;
        private DevExpress.XtraGrid.GridControl gridDSMon;
        private DevExpress.XtraGrid.Views.Grid.GridView GridView_DSMon;
        private DevExpress.XtraEditors.TextEdit textEditTT1;
        private DevExpress.XtraEditors.LabelControl labelControl3;
        private DevExpress.XtraEditors.TextEdit textEditVAT;
        private DevExpress.XtraEditors.LabelControl labelControl4;
        private DevExpress.XtraEditors.LabelControl labelControl5;
        private DevExpress.XtraEditors.TextEdit textEditTT2;
        private DevExpress.XtraEditors.LabelControl labelControl6;
        private DevExpress.XtraEditors.LabelControl labelControl7;
        private DevExpress.XtraEditors.LabelControl labelControl8;
        private DevExpress.XtraEditors.LabelControl labelControl9;
        private DevExpress.XtraEditors.LabelControl labelControl10;
        private DevExpress.XtraEditors.TextEdit textEditGiamGia;
        private DevExpress.XtraEditors.TextEdit textEditTT3;
        private DevExpress.XtraEditors.LabelControl labelControl11;
        private DevExpress.XtraEditors.TextEdit TextEditTongTien;
        private DevExpress.XtraEditors.LabelControl labelControl12;
        private DevExpress.XtraEditors.LabelControl labelControl13;
        private DevExpress.XtraEditors.SimpleButton simpleButton2;
        private DevExpress.XtraEditors.SimpleButton simpleButton3;
        private System.Windows.Forms.SplitContainer splitContainer1;
        private DevExpress.XtraEditors.SimpleButton simpleButton1;
        private DevExpress.XtraEditors.SimpleButton simpleButton5;
        private DevExpress.XtraEditors.SimpleButton btnTru;
        private DevExpress.XtraEditors.SimpleButton btnCong;
        private DevExpress.XtraPrinting.PrintingSystem printingSystem2;
        private DevExpress.XtraPrinting.PrintableComponentLink printableComponentLink2;
    }
}
