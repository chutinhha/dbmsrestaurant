﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using DAO;
using DTO;
using System.Data;
using System.Data.SqlClient;


namespace BUS
{
    public class KhachHang_BUS
    {
        public static DataTable DocKhacHang()
        {
            return KhachHang_DAO.DocKhachHang();
        }
    }
}
