﻿namespace GUI.TiepTan
{
    partial class UCtrlDSDatBan
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupControl2 = new DevExpress.XtraEditors.GroupControl();
            this.cbB_LoaiBan = new System.Windows.Forms.ComboBox();
            this.lb_LoaiBan = new DevExpress.XtraEditors.LabelControl();
            this.cbB_TinhTrang = new System.Windows.Forms.ComboBox();
            this.comboBox3 = new System.Windows.Forms.ComboBox();
            this.labelControl1 = new DevExpress.XtraEditors.LabelControl();
            this.lb_KhuVuc = new DevExpress.XtraEditors.LabelControl();
            this.cbB_MaBan = new System.Windows.Forms.ComboBox();
            this.lb_MaBan = new DevExpress.XtraEditors.LabelControl();
            this.groupControl1 = new DevExpress.XtraEditors.GroupControl();
            this.gridDSDatBan = new DevExpress.XtraGrid.GridControl();
            this.gridView1 = new DevExpress.XtraGrid.Views.Grid.GridView();
            this.btnDatBan = new DevExpress.XtraEditors.SimpleButton();
            this.btnCapNhat = new DevExpress.XtraEditors.SimpleButton();
            this.btnXoa = new DevExpress.XtraEditors.SimpleButton();
            this.btnInDSNV = new DevExpress.XtraEditors.SimpleButton();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).BeginInit();
            this.groupControl2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).BeginInit();
            this.groupControl1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.gridDSDatBan)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // groupControl2
            // 
            this.groupControl2.Controls.Add(this.cbB_LoaiBan);
            this.groupControl2.Controls.Add(this.lb_LoaiBan);
            this.groupControl2.Controls.Add(this.cbB_TinhTrang);
            this.groupControl2.Controls.Add(this.comboBox3);
            this.groupControl2.Controls.Add(this.labelControl1);
            this.groupControl2.Controls.Add(this.lb_KhuVuc);
            this.groupControl2.Controls.Add(this.cbB_MaBan);
            this.groupControl2.Controls.Add(this.lb_MaBan);
            this.groupControl2.Location = new System.Drawing.Point(3, 12);
            this.groupControl2.Name = "groupControl2";
            this.groupControl2.Size = new System.Drawing.Size(435, 127);
            this.groupControl2.TabIndex = 4;
            this.groupControl2.Text = "Tùy Chọn";
            // 
            // cbB_LoaiBan
            // 
            this.cbB_LoaiBan.FormattingEnabled = true;
            this.cbB_LoaiBan.Location = new System.Drawing.Point(294, 81);
            this.cbB_LoaiBan.Name = "cbB_LoaiBan";
            this.cbB_LoaiBan.Size = new System.Drawing.Size(121, 21);
            this.cbB_LoaiBan.TabIndex = 1;
            // 
            // lb_LoaiBan
            // 
            this.lb_LoaiBan.Location = new System.Drawing.Point(231, 84);
            this.lb_LoaiBan.Name = "lb_LoaiBan";
            this.lb_LoaiBan.Size = new System.Drawing.Size(40, 13);
            this.lb_LoaiBan.TabIndex = 0;
            this.lb_LoaiBan.Text = "Loại Bàn";
            // 
            // cbB_TinhTrang
            // 
            this.cbB_TinhTrang.FormattingEnabled = true;
            this.cbB_TinhTrang.Location = new System.Drawing.Point(294, 41);
            this.cbB_TinhTrang.Name = "cbB_TinhTrang";
            this.cbB_TinhTrang.Size = new System.Drawing.Size(121, 21);
            this.cbB_TinhTrang.TabIndex = 1;
            // 
            // comboBox3
            // 
            this.comboBox3.FormattingEnabled = true;
            this.comboBox3.Location = new System.Drawing.Point(80, 81);
            this.comboBox3.Name = "comboBox3";
            this.comboBox3.Size = new System.Drawing.Size(121, 21);
            this.comboBox3.TabIndex = 1;
            // 
            // labelControl1
            // 
            this.labelControl1.Location = new System.Drawing.Point(231, 45);
            this.labelControl1.Name = "labelControl1";
            this.labelControl1.Size = new System.Drawing.Size(51, 13);
            this.labelControl1.TabIndex = 0;
            this.labelControl1.Text = "Tình Trạng";
            // 
            // lb_KhuVuc
            // 
            this.lb_KhuVuc.Location = new System.Drawing.Point(17, 85);
            this.lb_KhuVuc.Name = "lb_KhuVuc";
            this.lb_KhuVuc.Size = new System.Drawing.Size(39, 13);
            this.lb_KhuVuc.TabIndex = 0;
            this.lb_KhuVuc.Text = "Khu Vực";
            // 
            // cbB_MaBan
            // 
            this.cbB_MaBan.FormattingEnabled = true;
            this.cbB_MaBan.Location = new System.Drawing.Point(80, 42);
            this.cbB_MaBan.Name = "cbB_MaBan";
            this.cbB_MaBan.Size = new System.Drawing.Size(121, 21);
            this.cbB_MaBan.TabIndex = 1;
            // 
            // lb_MaBan
            // 
            this.lb_MaBan.Location = new System.Drawing.Point(17, 46);
            this.lb_MaBan.Name = "lb_MaBan";
            this.lb_MaBan.Size = new System.Drawing.Size(35, 13);
            this.lb_MaBan.TabIndex = 0;
            this.lb_MaBan.Text = "Mã Bàn";
            // 
            // groupControl1
            // 
            this.groupControl1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom)
                        | System.Windows.Forms.AnchorStyles.Left)
                        | System.Windows.Forms.AnchorStyles.Right)));
            this.groupControl1.Controls.Add(this.gridDSDatBan);
            this.groupControl1.Location = new System.Drawing.Point(3, 145);
            this.groupControl1.Name = "groupControl1";
            this.groupControl1.Size = new System.Drawing.Size(874, 291);
            this.groupControl1.TabIndex = 5;
            this.groupControl1.Text = "Danh Sách Đặt Bàn";
            // 
            // gridDSDatBan
            // 
            this.gridDSDatBan.Dock = System.Windows.Forms.DockStyle.Fill;
            this.gridDSDatBan.Location = new System.Drawing.Point(2, 22);
            this.gridDSDatBan.MainView = this.gridView1;
            this.gridDSDatBan.Name = "gridDSDatBan";
            this.gridDSDatBan.Size = new System.Drawing.Size(870, 267);
            this.gridDSDatBan.TabIndex = 0;
            this.gridDSDatBan.ViewCollection.AddRange(new DevExpress.XtraGrid.Views.Base.BaseView[] {
            this.gridView1});
            // 
            // gridView1
            // 
            this.gridView1.GridControl = this.gridDSDatBan;
            this.gridView1.Name = "gridView1";
            // 
            // btnDatBan
            // 
            this.btnDatBan.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnDatBan.Image = global::GUI.Properties.Resources.add_16;
            this.btnDatBan.Location = new System.Drawing.Point(413, 442);
            this.btnDatBan.Name = "btnDatBan";
            this.btnDatBan.Size = new System.Drawing.Size(190, 26);
            this.btnDatBan.TabIndex = 16;
            this.btnDatBan.Text = "Đặt Bàn";
            this.btnDatBan.Click += new System.EventHandler(this.btnDatBan_Click);
            // 
            // btnCapNhat
            // 
            this.btnCapNhat.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnCapNhat.Image = global::GUI.Properties.Resources.save_16;
            this.btnCapNhat.Location = new System.Drawing.Point(609, 442);
            this.btnCapNhat.Name = "btnCapNhat";
            this.btnCapNhat.Size = new System.Drawing.Size(89, 26);
            this.btnCapNhat.TabIndex = 17;
            this.btnCapNhat.Text = "Cập Nhật";
            // 
            // btnXoa
            // 
            this.btnXoa.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnXoa.Image = global::GUI.Properties.Resources.delete_16;
            this.btnXoa.Location = new System.Drawing.Point(704, 442);
            this.btnXoa.Name = "btnXoa";
            this.btnXoa.Size = new System.Drawing.Size(61, 26);
            this.btnXoa.TabIndex = 19;
            this.btnXoa.Text = "Xóa";
            // 
            // btnInDSNV
            // 
            this.btnInDSNV.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.btnInDSNV.Image = global::GUI.Properties.Resources.print_24;
            this.btnInDSNV.Location = new System.Drawing.Point(771, 442);
            this.btnInDSNV.Name = "btnInDSNV";
            this.btnInDSNV.Size = new System.Drawing.Size(106, 26);
            this.btnInDSNV.TabIndex = 18;
            this.btnInDSNV.Text = "In Danh Sách";
            // 
            // UCtrlDSDatBan
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.btnDatBan);
            this.Controls.Add(this.groupControl1);
            this.Controls.Add(this.btnCapNhat);
            this.Controls.Add(this.groupControl2);
            this.Controls.Add(this.btnXoa);
            this.Controls.Add(this.btnInDSNV);
            this.Name = "UCtrlDSDatBan";
            this.Size = new System.Drawing.Size(880, 480);
            ((System.ComponentModel.ISupportInitialize)(this.groupControl2)).EndInit();
            this.groupControl2.ResumeLayout(false);
            this.groupControl2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.groupControl1)).EndInit();
            this.groupControl1.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.gridDSDatBan)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.gridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private DevExpress.XtraEditors.GroupControl groupControl2;
        private System.Windows.Forms.ComboBox cbB_LoaiBan;
        private DevExpress.XtraEditors.LabelControl lb_LoaiBan;
        private System.Windows.Forms.ComboBox cbB_TinhTrang;
        private System.Windows.Forms.ComboBox comboBox3;
        private DevExpress.XtraEditors.LabelControl labelControl1;
        private DevExpress.XtraEditors.LabelControl lb_KhuVuc;
        private System.Windows.Forms.ComboBox cbB_MaBan;
        private DevExpress.XtraEditors.LabelControl lb_MaBan;
        private DevExpress.XtraEditors.GroupControl groupControl1;
        private DevExpress.XtraEditors.SimpleButton btnDatBan;
        private DevExpress.XtraEditors.SimpleButton btnCapNhat;
        private DevExpress.XtraEditors.SimpleButton btnXoa;
        private DevExpress.XtraEditors.SimpleButton btnInDSNV;
        private DevExpress.XtraGrid.GridControl gridDSDatBan;
        private DevExpress.XtraGrid.Views.Grid.GridView gridView1;
    }
}
